The DDR init scripts within this folder are for FSL reference boards. Customers can take these script as reference for their own boards. 
Please contact FSL in case the scripts have been updated.

