The scripts in the script folders for each SoC may not be the latest script and just for reference.
Please use the latest FSL DDR Register Programming Aid to generate your own script.